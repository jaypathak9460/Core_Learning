﻿using System;
using System.Activities;
using System.Activities.Statements;
using System.Linq;
using System.ServiceModel;

namespace InMemoryDbWCF_Host
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Activity workflow1 = new Workflow1();
            //WorkflowInvoker.Invoke(workflow1);
            ServiceHost host = new ServiceHost(typeof(InMemorydbWCF.Services.CustomerService));
            host.Open();
            Console.WriteLine("Service Hosted Sucessfully");
            Console.Read();
        }
    }
}
