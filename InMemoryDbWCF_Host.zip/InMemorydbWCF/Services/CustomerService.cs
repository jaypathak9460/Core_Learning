﻿using InMemorydbWCF.Interfaces;
using InMemorydbWCF.Models;
using System;
using System.Activities.Statements;
using System.Collections.Generic;


namespace InMemorydbWCF.Services
{
    public  class CustomerService : ICustomerService
    {
       private static List<Customer> customers = new List<Customer>();

        private readonly Database db;
        public CustomerService()
        {
            db = new Database(customers);
        }
        public Customer AddData(Customer customer)
        {
            try
            {
                db.AddCustomerToDB(ref customer);
                return customer;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string DeleteData(Guid Id)
        {
            try
            {
                var i = db.RemoveCustomerFromDB(Id);
                if (i == 1)
                {
                    return "Customer Deleted SuccessFully";
                }
                else {
                    return "Customer isnt Exists";
                }
            }
            catch (Exception)
            {
                return "Threre is some Error Occure!";
            }

        }

        public Customer UpdateData(Customer customer)
        {
            try
            {
                var response  = db.UpdateCustomerToDB( customer);
                return response;
            }
            catch (Exception)
            {

                throw;
            }
          
        }

        public List<Customer> GetAllData()
        {   
            try
            {
                var listOfCustomer = db.GetAllCustomers();
                return listOfCustomer;
            }
            catch (Exception)
            {
                    
                throw;
            }
           
        }
    }
}
