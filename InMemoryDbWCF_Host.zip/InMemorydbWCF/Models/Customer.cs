﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace InMemorydbWCF.Models
{
    [DataContract]

    public class Customer
    {
        [DataMember]
        public Guid? Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Email { get; set; }
        public string GetNameWithEmail
        {
            get
            {
                return "Name: " + Name + " => Email: " + Email;
            }
        }

    }
}
