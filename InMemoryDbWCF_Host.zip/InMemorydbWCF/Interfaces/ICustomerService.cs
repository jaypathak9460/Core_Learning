﻿using InMemorydbWCF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace InMemorydbWCF.Interfaces
{
    [ServiceContract]
    public interface ICustomerService
    {
        [OperationContract]

        Customer AddData(Customer customer);
        [OperationContract]

        Customer UpdateData(Customer customer);
        [OperationContract]

        string DeleteData(Guid Id);
        [OperationContract]
        List<Customer> GetAllData();
    }
}
