﻿using InMemorydbWCF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace InMemorydbWCF
{
    public class Database
    {
        private readonly List<Customer> customersdb;
        public Database(List<Customer> customers)
        {
            customersdb = customers;
        }
        public Customer AddCustomerToDB(ref Customer customer)
        {
            customer.Id = Guid.NewGuid();
            customersdb.Add(customer);
            return customer;

        }
        public int RemoveCustomerFromDB(Guid id)
        {
            //check if customer exists or not 
            var checkCustomer = customersdb.Where(s => s.Id == id).FirstOrDefault();
            if (checkCustomer != null)
            {
                customersdb.Remove(checkCustomer);
                return 1;
            }
            else
            {
                return 0;
                //throw new Exception("Customer not Exists");        
            }
        }


        public Customer UpdateCustomerToDB( Customer customer)
        {
            Guid? CustomerId = customer.Id;
            var existingCustomer = customersdb.Where(s => s.Id == CustomerId).FirstOrDefault();
            if (existingCustomer != null)
            {
                existingCustomer.Name = customer.Name;
                existingCustomer.Email = customer.Email;
                return existingCustomer;
            }
            else
            {

                throw new Exception("Customer not Exists");
            }

        }

        public List<Customer> GetAllCustomers()
        {
            return customersdb;

        }

    }
}
